package com.practiceJava8.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import com.practiceJava8.streams.model.Students;

public class parallelStreamDemo {

	public static void main(String[] args) {

		List<Students> list = new ArrayList<>();
		list.add(new Students("nikhil", 22));
		list.add(new Students("yashaswini", 21));
		list.add(new Students("saifi", 21));
		list.add(new Students("tanya", 22));
		list.add(new Students("ranjana", 22));

		Stream<Students> parallelStream = list.parallelStream();

		parallelStream.forEach(s -> doProcess(s));
	}

	private static void doProcess(Students s) {
		System.out.println(s);
	}

}
