package com.practiceJava8.streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Streams {

	public static void main(String[] args) {
		String[] arr=new String[] {"a","b","c"};
		Stream<String> stream=Arrays.stream(arr);
		stream.forEach(System.out::println);
		
		Stream<String> of =Stream.of("A", "B", "C");
		System.out.println("*******************");
		of.forEach(System.out::println);
		
		
		List<String> list=new ArrayList<>();
		list.add("nikhil");
		list.add("Yashaswini");
		list.add("saifi");
		
		Stream<String> stream2=list.stream();
		System.out.println("********************");
		stream2.forEach(System.out::println);
	}
	
}
