package com.practiceJava8.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class StreamOps {

	public static void main(String[] args) {
		
	    List<String> list = new ArrayList<>();
	    list.add("nikhil");
	    list.add("saifi");
	    list.add("tanya");
	    list.add("ashish");
	    list.add("ashish");
	    list.add("ashish");
	    
	    /*Stream<String> stream = list.stream();*/
	    
	    long count = list.stream().distinct().count();
	   System.out.println(count);
	    
	   /* boolean isExist = list.stream().anyMatch(a->a.contains("a"));
	    System.out.println(isExist);*/
	    
	    
	
	    
	    
	}
}
