package com.cloud.Parking.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.cloud.Parking.pojo.Customer;
import com.cloud.Parking.pojo.GenerateId;

public class ParkingService {
     
	private static int compartment=1;
	private static int section=1;
	private static int floor=1;
	
	Map<GenerateId,Customer> parkingMap;
	
	public ParkingService() 
	{
	   parkingMap= new HashMap<GenerateId, Customer>();	
	}
	
	
	public Set<Map.Entry<GenerateId, Customer>> getAllCarsLocation()
	{
		return parkingMap.entrySet();
	}
	
	
	
	
	
	public void parkCar(Customer customerDetail)
	{
        if(compartment>10)
        {
               section++;
               compartment=1;
               if(section>4)
               {
                     floor++;
                     section=1;
                     compartment=1;
               }
        }
        GenerateId key=new GenerateId(floor,section,compartment);
        
      
        parkingMap.put(key, customerDetail);
        if(floor==4&&section==4&&compartment==11)
        	throw new RuntimeException("No space available");
        compartment++;
        customerDetail.setParkId(key);

	}


	public Customer getCarParkingId(GenerateId parkId) {
		
		return parkingMap.get(parkId);
	}
	
}
