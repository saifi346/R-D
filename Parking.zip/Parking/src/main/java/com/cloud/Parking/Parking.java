package com.cloud.Parking;

import java.util.HashMap;
import java.util.Map;

import com.cloud.Parking.Service.ParkingService;
import com.cloud.Parking.pojo.Customer;
import com.cloud.Parking.pojo.GenerateId;

public class Parking 
{
    public static void main( String[] args )
    {
        ParkingService ps=new ParkingService();
        Customer cust=new Customer("Sparsh", "9892939495", "06:20");
        
        
        ps.parkCar(new Customer("Ashish", "9892939495", "06:20"));
        ps.parkCar(new Customer("Nikhil", "9892939495", "06:20"));
        ps.parkCar(cust);
        ps.parkCar(new Customer("Vishnu", "9892939495", "06:20"));
        ps.parkCar(new Customer("Saifi", "9892939495", "06:20"));
        ps.parkCar(new Customer("Yashaswini","9892939495", "06:20"));
        ps.parkCar(new Customer("Ranjana", "9892939495", "06:20"));
        ps.parkCar(new Customer("Bindu", "9892939495", "06:20"));
        ps.parkCar(new Customer("Ramya", "9892939495", "06:20"));
        ps.parkCar(new Customer("Dhrubo", "9892939495", "06:20"));
        ps.parkCar(new Customer("Kartik", "9892939495", "06:20"));
        ps.parkCar(new Customer("Dhanya", "9892939495", "06:20"));
        
        for (Map.Entry m : ps.getAllCarsLocation()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
        
        
        
        System.out.println(ps.getCarParkingId(cust.getParkId()));
        
    }
}
