package com.cloud.Parking.pojo;

import java.util.Date;

public class Customer {

	String custName;
	String phoneNo;
	String Time;
	GenerateId parkId;
	
	
	
	public Customer(String custName, String phoneNo, String time) {
		super();
		this.custName = custName;
		this.phoneNo = phoneNo;
		Time = time;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getTime() {
		return Time;
	}
	public void setTime(String time) {
		Time = time;
	}
	
	public GenerateId getParkId() {
		return parkId;
	}
	public void setParkId(GenerateId parkId) {
		this.parkId = parkId;
	}
	
	@Override
	public String toString() {
		return "Customer [custName=" + custName + ", phoneNo=" + phoneNo + ", Time=" + Time + "]";
	}
	
	
	
	
	
	
}
