package com.saifi.date.service;

import com.saifi.date.pojo.MyDate;

public class DateDiffrenceProvider {
	private static int JAN=31;
	private static int FEB=28;
	private static int MAR=31;
	private static int APRIL=30;
	private static int MAY=31;
	private static int JUNE=30;
	private static int JULY=31;
	private static int AUG=31;
	private static int SEPT=30;
	private static int OCT=31;
	private static int NOV=30;
	private static int DEC=31;
	
	private static int months[]= {JAN, FEB, MAR, APRIL, MAY, JUNE, JULY, AUG, SEPT, OCT, NOV, DEC};
	
	public static int getDateDifference(MyDate startDate,MyDate endDate) {
//		//getting startDate values
//		int day1=startDate.getDd();
//		int month1=startDate.getMm();
//		int year1=startDate.getYyyy();
//		
//		//getting endDate values
//		int day2=endDate.getDd();
//		int month2=endDate.getMm();
//		int year2=endDate.getYyyy();
//		int days=0;
//		int daysInYear=0;
		
		if(sameDay(startDate,endDate) && sameMonth(startDate,endDate) && sameYear(startDate,endDate)) {
			return 0;
		}
		
		else if(sameMonth(startDate,endDate) && sameYear(startDate,endDate)) {
			return endDate.getDd()-startDate.getDd();
		}
		
		else if(sameYear(startDate, endDate))
		{
			return (remainingDays(startDate)+intervingMonth(startDate, endDate)+leadingDays(endDate));
		}
		
		else {
			return (remainingMonths(startDate)+intervingYear(startDate, endDate)+leadingMonths(endDate));
		}

		
		
		
		
//		if(year1!=year2)
//		{
//			if(year1%4==0)
//			{
//				daysInYear=366;
//				
//			}
//			else
//			{
//				if(month1!=month2)
//				{
//				   days=months[month1-1]-day1;
//				   for(int i=month1;i<12;i++)
//				   {
//					   days+=months[i];
//				   }
//				   for(int i=1;i<month2;i++)
//				   {
//					   days+=months[i];
//				   }
//				   
//				   
//				}
//			}
//			return days;
//		}
//		
//		if(month1!=month2)
//		{
//		   days=months[month1-1]-day1;
//		   for(int i=month1;i<month2-1;i++)
//		   {
//			   days+=months[i];
//		   }
//		   days+=day2;
//		   return days;
//		}
//		
//		if(day1!=day2)
//		{
//			days=(day2-day1)+(month2-month1)+(year2-year1);
//			return days;
//		}
////		int days=(day2-day1)+(month2-month1)+(year2-year1);
//		return days;
	}

	

	
	




	



	




	


















	

















	


















	private static boolean sameDay(MyDate startDate, MyDate endDate) {
		if(startDate.getDd()==endDate.getDd())
		   return true;
		return false;
	}
	
	private static boolean sameMonth(MyDate startDate, MyDate endDate) {
		if(startDate.getMm()==endDate.getMm())
			return true;
		return false;
	}
	
	private static boolean sameYear(MyDate startDate, MyDate endDate) {
		if(startDate.getYyyy()==endDate.getYyyy())
			return true;
		return false;
	}
	
	private static int remainingDays(MyDate startDate) {
		int remainingDays=0;
		if(isLeapYear(startDate) && startDate.getMm()==2)
			remainingDays=1;
		remainingDays+=months[startDate.getMm()-1]-startDate.getDd();
		return remainingDays;
	}
	
	private static int leadingDays(MyDate endDate) {
		return endDate.getDd();
	}
	
	private static int intervingMonth(MyDate startDate, MyDate endDate) {
		int intervingMonthDays=0;
		if(isLeapYear(startDate) && startDate.getMm()<2 && endDate.getMm()>2)
			intervingMonthDays=1;
		for(int i=startDate.getMm();i<endDate.getMm()-1;i++)
		{   
			intervingMonthDays+=months[i];
		}
		return intervingMonthDays;
	}
	
	private static boolean isLeapYear(MyDate startDate) {
		if((startDate.getYyyy()%4==0 && startDate.getYyyy()%100!=0)|| startDate.getYyyy()%400==0) 
			return true;
		return false;
	}


	private static int remainingMonths(MyDate startDate) {
		 int remainingYearDays=0;
		 int remainDaysInMonth=remainingDays(startDate);
		 int intervingMonthDays=intervingMonth(startDate, new MyDate(0, 13, startDate.getYyyy()));
		 remainingYearDays=remainDaysInMonth+intervingMonthDays;
		 return remainingYearDays;
	}
	
	private static int intervingYear(MyDate startDate, MyDate endDate) {
		int intervingYearDays=0;
		for(int j=startDate.getYyyy()+1;j<endDate.getYyyy();j++)
		{
			if((j%4==0 && j%100!=0) || j%400==0)
				intervingYearDays+=366;
			else
				intervingYearDays+=365;
		}
		return intervingYearDays;
	}
	
	private static int leadingMonths(MyDate endDate) {
		int leadingYearDays=0;
		int intervingMonthDays=intervingMonth(new MyDate(0, 0, endDate.getYyyy()), endDate);
		int leadingDaysInMonth=endDate.getDd();
		leadingYearDays=leadingDaysInMonth+intervingMonthDays;
		return leadingYearDays;
	}
	public static void main(String[] args) {
		System.out.println(leadingMonths(new MyDate(18, 12, 2012)));
	}
}
