package com.cloud.makeMyTrip.service;

import java.util.ArrayList;
import java.util.Collections;

import java.util.LinkedList;
import java.util.TreeSet;

import com.cloud.makeMyTrip.pojo.FlightDetails;




public class FlightService {
     
	ArrayList<FlightDetails> flightList=new ArrayList<FlightDetails>();
	
	public void addFlight(FlightDetails flight)
	{
		flightList.add(flight);
	}
	
	public ArrayList<FlightDetails> removeFlight(int flightId)
	{
		for (FlightDetails flight : flightList) {
			if (flight.getFlightNo() == flightId)
				flightList.remove(flightId);
			return flightList;
		}

		throw new RuntimeException("flight does not exist");
	}
	
	public ArrayList<FlightDetails> getAllFlightDetails(){
		return flightList;
	}
	
	public FlightDetails getFlightDetailsById(int flightId){
		for (FlightDetails flight : flightList) {
			if (flight.getFlightNo() == flightId)
				return flight;
		}

		throw new RuntimeException("flight does not exist");
	}
	
	public ArrayList<FlightDetails> upintFlightSource(int flightId,String source)
	{
		for (FlightDetails flight : flightList) {
			if (flight.getFlightNo() == flightId)
				flight.setSource(source);
			return flightList;
		}

		throw new RuntimeException("flight does not exist");
	}
	
	public ArrayList<FlightDetails> upintFlightDestination(int flightId,String destination)
	{
		for (FlightDetails flight : flightList) {
			if (flight.getFlightNo() == flightId)
				flight.setDestination(destination);
			return flightList;
		}

		throw new RuntimeException("flight does not exist");
	}
	
	public ArrayList<FlightDetails> upintFlightDepartureTime(int flightId,int departureTime)
	{
		for (FlightDetails flight : flightList) {
			if (flight.getFlightNo() == flightId)
				flight.setDepartureTime(departureTime);
			return flightList;
		}

		throw new RuntimeException("flight does not exist");
	}
	
	public ArrayList<FlightDetails> upintFlightArrivalTime(int flightId,int arrivalTime)
	{
		for (FlightDetails flight : flightList) {
			if (flight.getFlightNo() == flightId)
				flight.setArrivalTime(arrivalTime);
			return flightList;
		}

		throw new RuntimeException("flight does not exist");
	}
	
	public ArrayList<FlightDetails> sortByCost()
    {
           Collections.sort(flightList,(FlightDetails flightList1,FlightDetails flightList2) -> flightList1.getCost()-flightList2.getCost());
           return flightList;
                        
    }
	
	public ArrayList<FlightDetails> sortByTime()
    {
		Collections.sort(flightList,(FlightDetails flightList1,FlightDetails flightList2) -> flightList1.getRouteTime()-flightList2.getRouteTime());
        return flightList;
                        
    }
	
	public ArrayList<FlightDetails> morningFlights()
    {
		ArrayList<FlightDetails> morningFlights=new ArrayList<FlightDetails>();
		for (FlightDetails flight : flightList) {
			if (flight.getDepartureTime()>=600 && flight.getDepartureTime()<1200)
				morningFlights.add(flight);
			return morningFlights;
		}

		throw new RuntimeException("flight does not exist");
	}

	
}
