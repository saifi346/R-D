package com.cloud.makeMyTrip.passenger;

import com.cloud.makeMyTrip.pojo.FlightDetails;
import com.cloud.makeMyTrip.service.FlightService;

public class Passenger {

	public static void main(String[] args) {
		
	
	    FlightDetails flight1=new FlightDetails("Indigo", 2000, "Delhi", "Bangalore", 0300, 0700);
	    FlightDetails flight2=new FlightDetails("Indigo", 3000, "Delhi", "Mumbai", 2300, 0200);
	    FlightDetails flight3=new FlightDetails("AirIndia", 7000, "Mumbai", "Laddhak", 1200, 0000);
	    FlightDetails flight4=new FlightDetails("SpiceJet", 12000, "Kerala", "Lucknow", 1300, 2200);
	    FlightDetails flight5=new FlightDetails("Qatar Airways", 25000, "Delhi", "Dubai", 1300, 0200);
	    
	    FlightService flightList=new FlightService();
	    flightList.addFlight(flight1);
	    flightList.addFlight(flight2);
	    flightList.addFlight(flight3);
	    flightList.addFlight(flight4);
	    flightList.addFlight(flight5);
	    
	    
	    System.out.println("All Flight Details");
	    System.out.println(flightList.getAllFlightDetails());
	    
	    flightList.sortByTime();
	    System.out.println("All Flight Details after sorting");
	    System.out.println(flightList.getAllFlightDetails());
	
  }
}