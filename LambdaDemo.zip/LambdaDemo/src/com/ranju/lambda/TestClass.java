package com.ranju.lambda;

public class TestClass {
	public static void main(String[] args) {
		
	MyInterface1 myInterface1 = () -> System.out.println("Lambda 1..") , myInterface2 = () -> System.out.println("Lambda 2..");
	myInterface1.method1();
	
	myInterface2.method1();
	System.out.println("------------");
	MyInterface2 myInterface3=(n1,n2) -> n1>n2;
	boolean value=myInterface3. method2(6,5);
	System.out.println("greater of 2 no's  "+value);
	System.out.println("------------");
	}
}
