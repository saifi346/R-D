package com.ranju.lambda;

public interface MyInterface1 {
	
	public abstract void method1();
}
