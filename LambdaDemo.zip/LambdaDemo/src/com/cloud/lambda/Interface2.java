package com.cloud.lambda;

public interface Interface2 {
 public abstract boolean method2(int n1,int n2);
}
