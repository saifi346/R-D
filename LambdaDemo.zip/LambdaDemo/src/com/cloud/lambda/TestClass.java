package com.cloud.lambda;

public class TestClass {
	 public static void main(String[] args) {
		
	Interface1 ref1 = () -> System.out.println("Lambda 1..") , ref2 = () -> System.out.println("Lambda 2..");
	ref1.method1();
	
	ref2.method1();
	System.out.println("***************");
	Interface2 interface2=(n1,n2) -> n1>n2;
	boolean result=interface2. method2(9,2);
	System.out.println("9 is greater than 2: "+result);
	System.out.println("**************");
	}
}
