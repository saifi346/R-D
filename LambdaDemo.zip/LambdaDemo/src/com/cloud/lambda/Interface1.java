package com.cloud.lambda;

public interface Interface1 {
	
	public abstract void method1();
}
